package com.example.jitstudentsdetails;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    public static String Name;
    public static String Age;
    public static String Bio;
    public static String Mobile;
    public static String Location;
    public static String getName(){
        return Name;
    }
    public static String getAge(){
        return Age;
    }
    public static String getBio(){
        return Bio;
    }
    public static String getMobile(){
        return Mobile;
    }
    public static String getLocation() {
        return Location;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b = findViewById(R.id.login);

        EditText name1= findViewById(R.id.name);
        EditText age= findViewById(R.id.age);
        EditText bio= findViewById(R.id.bio);
        EditText mn= findViewById(R.id.mobile_no);
        EditText l= findViewById(R.id.location);




        b.setOnClickListener(v -> {
            if(name1.getText().toString().isEmpty()){
                Toast.makeText(MainActivity.this,"Login Failed!! ",Toast.LENGTH_LONG).show();

            }
            else if(age.getText().toString().isEmpty()){
                Toast.makeText(MainActivity.this,"Login Failed!!",Toast.LENGTH_LONG).show();

            }
            else if(bio.getText().toString().isEmpty()){
                Toast.makeText(MainActivity.this,"Login Failed!!",Toast.LENGTH_LONG).show();

            }
            else if(mn.getText().toString().isEmpty()){
                Toast.makeText(MainActivity.this,"Login Failed!!",Toast.LENGTH_LONG).show();

            }
            else if(l.getText().toString().isEmpty()){
                Toast.makeText(MainActivity.this,"Login Failed!!",Toast.LENGTH_LONG).show();

            }else{
                Name=name1.getText().toString().trim();
                Age=age.getText().toString().trim();
                Bio=bio.getText().toString().trim();
                Mobile=mn.getText().toString().trim();
                Location=l.getText().toString().trim();
                Intent intent=new Intent(MainActivity.this,profile.class);
                startActivity(intent);
            }
        });

    }


}





