package com.example.jitstudentsdetails;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.widget.TextView;

public class profile extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        TextView username=findViewById(R.id.name);
        TextView userage=findViewById(R.id.age);
        TextView userbio=findViewById(R.id.Biograph);
        TextView usermob=findViewById(R.id.mob);
        TextView userloc=findViewById(R.id.loc);




        username.setText(MainActivity.getName());
        userage.setText("AGE:  "+MainActivity.getAge());
        userbio.setText("Bio :\n" +MainActivity.getBio());
        usermob.setText("Mobile Number: "+MainActivity.getMobile());
        userloc.setText("Location: "+MainActivity.getLocation());



    }
}